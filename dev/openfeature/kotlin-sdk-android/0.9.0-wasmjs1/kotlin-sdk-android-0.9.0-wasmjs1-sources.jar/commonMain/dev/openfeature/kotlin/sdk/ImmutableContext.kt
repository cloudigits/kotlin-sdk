package dev.openfeature.kotlin.sdk

class ImmutableContext(
    private val targetingKey: String = "",
    attributes: Map<String, Value> = mapOf()
) : EvaluationContext {
    private val structure: ImmutableStructure = ImmutableStructure(attributes.toMap())
    override fun getTargetingKey(): String {
        return targetingKey
    }

    override fun withTargetingKey(targetingKey: String): ImmutableContext =
        ImmutableContext(
            targetingKey = targetingKey,
            attributes = this.structure.asMap()
        )

    override fun keySet(): Set<String> {
        return structure.keySet()
    }

    override fun getValue(key: String): Value? {
        return structure.getValue(key)
    }

    override fun asMap(): Map<String, Value> {
        return structure.asMap()
    }

    override fun asObjectMap(): Map<String, Any?> {
        return structure.asObjectMap()
    }

    override fun hashCode(): Int {
        var result = targetingKey.hashCode()
        result = 31 * result + structure.hashCode()
        return result
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ImmutableContext) return false

        if (targetingKey != other.targetingKey) return false
        if (structure != other.structure) return false

        return true
    }
}