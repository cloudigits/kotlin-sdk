package dev.openfeature.kotlin.sdk

import dev.openfeature.kotlin.sdk.FlagValueType.BOOLEAN
import dev.openfeature.kotlin.sdk.FlagValueType.DOUBLE
import dev.openfeature.kotlin.sdk.FlagValueType.INTEGER
import dev.openfeature.kotlin.sdk.FlagValueType.LONG
import dev.openfeature.kotlin.sdk.FlagValueType.OBJECT
import dev.openfeature.kotlin.sdk.FlagValueType.STRING
import dev.openfeature.kotlin.sdk.events.OpenFeatureProviderEvents
import dev.openfeature.kotlin.sdk.exceptions.ErrorCode
import dev.openfeature.kotlin.sdk.exceptions.OpenFeatureError
import dev.openfeature.kotlin.sdk.exceptions.OpenFeatureError.GeneralError
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow

private val typeMatchingException =
    GeneralError("Unable to match default value type with flag value type")

class OpenFeatureClient(
    private val openFeatureAPI: OpenFeatureAPIInstance,
    name: String? = null,
    version: String? = null,
    override val hooks: MutableList<Hook<*>> = mutableListOf()
) : Client {
    override val metadata: ClientMetadata = Metadata(name)
    private val hookSupport = HookSupport()
    override fun addHooks(hooks: List<Hook<*>>) {
        this.hooks += hooks
    }

    override val statusFlow = openFeatureAPI.statusFlow

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observe(): Flow<OpenFeatureProviderEvents> =
        openFeatureAPI.observe<OpenFeatureProviderEvents>()

    override fun getBooleanValue(key: String, defaultValue: Boolean): Boolean {
        return getBooleanDetails(key, defaultValue).value
    }

    override fun getBooleanValue(
        key: String,
        defaultValue: Boolean,
        options: FlagEvaluationOptions
    ): Boolean {
        return getBooleanDetails(key, defaultValue, options).value
    }

    override fun getBooleanDetails(
        key: String,
        defaultValue: Boolean
    ): FlagEvaluationDetails<Boolean> {
        return getBooleanDetails(key, defaultValue, FlagEvaluationOptions())
    }

    override fun getBooleanDetails(
        key: String,
        defaultValue: Boolean,
        options: FlagEvaluationOptions
    ): FlagEvaluationDetails<Boolean> {
        return evaluateFlag(BOOLEAN, key, defaultValue, options)
    }

    override fun getStringValue(key: String, defaultValue: String): String {
        return getStringDetails(key, defaultValue).value
    }

    override fun getStringValue(
        key: String,
        defaultValue: String,
        options: FlagEvaluationOptions
    ): String {
        return getStringDetails(key, defaultValue, options).value
    }

    override fun getStringDetails(
        key: String,
        defaultValue: String
    ): FlagEvaluationDetails<String> {
        return getStringDetails(key, defaultValue, FlagEvaluationOptions())
    }

    override fun getStringDetails(
        key: String,
        defaultValue: String,
        options: FlagEvaluationOptions
    ): FlagEvaluationDetails<String> {
        return evaluateFlag(STRING, key, defaultValue, options)
    }

    override fun getIntegerValue(key: String, defaultValue: Int): Int {
        return getIntegerDetails(key, defaultValue).value
    }

    override fun getIntegerValue(
        key: String,
        defaultValue: Int,
        options: FlagEvaluationOptions
    ): Int {
        return getIntegerDetails(key, defaultValue, options).value
    }

    override fun getIntegerDetails(
        key: String,
        defaultValue: Int
    ): FlagEvaluationDetails<Int> {
        return getIntegerDetails(key, defaultValue, FlagEvaluationOptions())
    }

    override fun getIntegerDetails(
        key: String,
        defaultValue: Int,
        options: FlagEvaluationOptions
    ): FlagEvaluationDetails<Int> {
        return evaluateFlag(INTEGER, key, defaultValue, options)
    }

    override fun getLongValue(key: String, defaultValue: Long): Long {
        return getLongDetails(key, defaultValue).value
    }

    override fun getLongValue(
        key: String,
        defaultValue: Long,
        options: FlagEvaluationOptions
    ): Long {
        return getLongDetails(key, defaultValue, options).value
    }

    override fun getLongDetails(
        key: String,
        defaultValue: Long
    ): FlagEvaluationDetails<Long> {
        return getLongDetails(key, defaultValue, FlagEvaluationOptions())
    }

    override fun getLongDetails(
        key: String,
        defaultValue: Long,
        options: FlagEvaluationOptions
    ): FlagEvaluationDetails<Long> {
        return evaluateFlag(LONG, key, defaultValue, options)
    }

    override fun getDoubleValue(key: String, defaultValue: Double): Double {
        return getDoubleDetails(key, defaultValue).value
    }

    override fun getDoubleValue(
        key: String,
        defaultValue: Double,
        options: FlagEvaluationOptions
    ): Double {
        return getDoubleDetails(key, defaultValue, options).value
    }

    override fun getDoubleDetails(
        key: String,
        defaultValue: Double
    ): FlagEvaluationDetails<Double> {
        return evaluateFlag(DOUBLE, key, defaultValue, FlagEvaluationOptions())
    }

    override fun getDoubleDetails(
        key: String,
        defaultValue: Double,
        options: FlagEvaluationOptions
    ): FlagEvaluationDetails<Double> {
        return evaluateFlag(DOUBLE, key, defaultValue, options)
    }

    override fun getObjectValue(key: String, defaultValue: Value): Value {
        return getObjectDetails(key, defaultValue).value
    }

    override fun getObjectValue(
        key: String,
        defaultValue: Value,
        options: FlagEvaluationOptions
    ): Value {
        return getObjectDetails(key, defaultValue, options).value
    }

    override fun getObjectDetails(
        key: String,
        defaultValue: Value
    ): FlagEvaluationDetails<Value> {
        return getObjectDetails(key, defaultValue, FlagEvaluationOptions())
    }

    override fun getObjectDetails(
        key: String,
        defaultValue: Value,
        options: FlagEvaluationOptions
    ): FlagEvaluationDetails<Value> {
        return evaluateFlag(OBJECT, key, defaultValue, options)
    }

    override fun track(trackingEventName: String, details: TrackingEventDetails?) {
        validateTrackingEventName(trackingEventName)
        val state = openFeatureAPI.getEvaluationState()
        state.provider.track(trackingEventName, state.context, details)
    }

    private fun <T> evaluateFlag(
        flagValueType: FlagValueType,
        key: String,
        defaultValue: T,
        optionsIn: FlagEvaluationOptions?
    ): FlagEvaluationDetails<T> {
        val options = optionsIn ?: FlagEvaluationOptions(listOf(), mapOf())
        val hints = options.hookHints
        var details = FlagEvaluationDetails(key, defaultValue)
        val state = openFeatureAPI.getEvaluationState()
        val provider = state.provider
        val mergedHooks: List<Hook<*>> = provider.hooks + options.hooks + hooks + openFeatureAPI.hooks
        val context = state.context
        val hooksWithContext: List<Pair<Hook<*>, HookContext<T>>> =
            mergedHooks
                .filter { it.supportsFlagValueType(flagValueType) }
                .map { hook ->
                    hook to HookContext(
                        key,
                        flagValueType,
                        defaultValue,
                        context,
                        this.metadata,
                        provider.metadata,
                        mutableMapOf()
                    )
                }
        try {
            hookSupport.beforeHooks(flagValueType, hooksWithContext, hints)
            shortCircuitIfNotReady()
            val providerEval = createProviderEvaluation(
                flagValueType,
                key,
                context,
                defaultValue,
                provider
            )
            details = FlagEvaluationDetails.from(providerEval, key)
            hookSupport.afterHooks(flagValueType, details, hooksWithContext, hints)
        } catch (error: Exception) {
            val errorCode = if (error is OpenFeatureError) {
                error.errorCode()
            } else {
                ErrorCode.GENERAL
            }

            details = details.copy(
                errorMessage = error.message,
                reason = Reason.ERROR.toString(),
                errorCode = errorCode
            )

            hookSupport.errorHooks(flagValueType, error, hooksWithContext, hints)
        }
        hookSupport.afterAllHooks(flagValueType, details, hooksWithContext, hints)
        return details
    }

    private fun shortCircuitIfNotReady() {
        val providerStatus = openFeatureAPI.getStatus()
        if (providerStatus == OpenFeatureStatus.NotReady) {
            throw OpenFeatureError.ProviderNotReadyError()
        } else if (providerStatus is OpenFeatureStatus.Fatal) {
            throw OpenFeatureError.ProviderFatalError()
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun <V> createProviderEvaluation(
        flagValueType: FlagValueType,
        key: String,
        context: EvaluationContext?,
        defaultValue: V,
        provider: FeatureProvider
    ): ProviderEvaluation<V> {
        return when (flagValueType) {
            BOOLEAN -> {
                val defaultBoolean = defaultValue as? Boolean ?: throw typeMatchingException
                val eval: ProviderEvaluation<Boolean> =
                    provider.getBooleanEvaluation(key, defaultBoolean, context)
                eval as? ProviderEvaluation<V> ?: throw typeMatchingException
            }

            STRING -> {
                val defaultString = defaultValue as? String ?: throw typeMatchingException
                val eval: ProviderEvaluation<String> =
                    provider.getStringEvaluation(key, defaultString, context)
                eval as? ProviderEvaluation<V> ?: throw typeMatchingException
            }

            INTEGER -> {
                val defaultInteger = defaultValue as? Int ?: throw typeMatchingException
                val eval: ProviderEvaluation<Int> =
                    provider.getIntegerEvaluation(key, defaultInteger, context)
                eval as? ProviderEvaluation<V> ?: throw typeMatchingException
            }

            LONG -> {
                val defaultLong = defaultValue as? Long ?: throw typeMatchingException
                val eval: ProviderEvaluation<Long> =
                    provider.getLongEvaluation(key, defaultLong, context)
                eval as? ProviderEvaluation<V> ?: throw typeMatchingException
            }

            DOUBLE -> {
                val defaultDouble = defaultValue as? Double ?: throw typeMatchingException
                val eval: ProviderEvaluation<Double> =
                    provider.getDoubleEvaluation(key, defaultDouble, context)
                eval as? ProviderEvaluation<V> ?: throw typeMatchingException
            }

            OBJECT -> {
                val defaultObject = defaultValue as? Value ?: throw typeMatchingException
                val eval: ProviderEvaluation<Value> =
                    provider.getObjectEvaluation(key, defaultObject, context)
                eval as? ProviderEvaluation<V> ?: throw typeMatchingException
            }
        }
    }

    data class Metadata(override val name: String?) : ClientMetadata
}

private fun validateTrackingEventName(name: String) {
    if (name.isEmpty()) {
        throw IllegalArgumentException("trackingEventName cannot be empty")
    }
}