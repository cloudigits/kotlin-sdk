package dev.openfeature.kotlin.sdk

class EvaluationMetadata internal constructor(private val values: Map<String, Any>) {

    fun getString(key: String): String? = values[key] as? String

    fun getBoolean(key: String): Boolean? = values[key] as? Boolean

    fun getInt(key: String): Int? = values[key] as? Int

    fun getLong(key: String): Long? = values[key] as? Long

    fun getDouble(key: String): Double? = values[key] as? Double

    companion object {
        fun builder(): Builder {
            return Builder()
        }

        val EMPTY = EvaluationMetadata(emptyMap())
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is EvaluationMetadata) return false

        return values == other.values
    }

    override fun hashCode(): Int {
        return values.hashCode()
    }
}

class Builder {
    private val values: MutableMap<String, Any> = mutableMapOf()

    fun putString(key: String, value: String): Builder {
        values[key] = value
        return this
    }

    fun putInt(key: String, value: Int): Builder {
        values[key] = value
        return this
    }

    fun putLong(key: String, value: Long): Builder {
        values[key] = value
        return this
    }

    fun putDouble(key: String, value: Double): Builder {
        values[key] = value
        return this
    }

    fun putBoolean(key: String, value: Boolean): Builder {
        values[key] = value
        return this
    }

    fun build(): EvaluationMetadata {
        return EvaluationMetadata(values.toMap())
    }
}